const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json());

const DATA_FILE = path.join(__dirname, 'products.json');

// Helper function to read products.json
function readProducts() {
    try {
        if (!fs.existsSync(DATA_FILE)) {
            fs.writeFileSync(DATA_FILE, JSON.stringify([]));
        }
        const data = fs.readFileSync(DATA_FILE);
        return JSON.parse(data);
    } catch (err) {
        throw new Error('Error reading products file');
    }
}

// Helper function to write products.json
function writeProducts(products) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(products, null, 2));
    } catch (err) {
        throw new Error('Error writing products file');
    }
}

// GET /products - get all products
app.get('/products', (req, res) => {
    try {
        const products = readProducts();
        res.json(products);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET /products/instock - get only in-stock products
app.get('/products/instock', (req, res) => {
    try {
        const products = readProducts();
        const inStockProducts = products.filter(p => p.inStock);
        res.json(inStockProducts);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST /products - create a new product
app.post('/products', (req, res) => {
    const { name, price, inStock } = req.body;
    if (!name || price === undefined || inStock === undefined) {
        return res.status(400).json({ error: 'Invalid input: name, price, and inStock are required' });
    }

    try {
        const products = readProducts();
        const newId = products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1;
        const newProduct = { id: newId, name, price, inStock };
        products.push(newProduct);
        writeProducts(products);
        res.status(201).json(newProduct);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PUT /products/:id - update a product
app.put('/products/:id', (req, res) => {
    const productId = parseInt(req.params.id);
    const { name, price, inStock } = req.body;

    try {
        const products = readProducts();
        const index = products.findIndex(p => p.id === productId);
        if (index === -1) {
            return res.status(404).json({ error: 'Product not found' });
        }

        if (name !== undefined) products[index].name = name;
        if (price !== undefined) products[index].price = price;
        if (inStock !== undefined) products[index].inStock = inStock;

        writeProducts(products);
        res.json(products[index]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE /products/:id - delete a product
app.delete('/products/:id', (req, res) => {
    const productId = parseInt(req.params.id);

    try {
        let products = readProducts();
        const index = products.findIndex(p => p.id === productId);
        if (index === -1) {
            return res.status(404).json({ error: 'Product not found' });
        }

        products.splice(index, 1);
        writeProducts(products);
        res.json({ message: 'Product deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
